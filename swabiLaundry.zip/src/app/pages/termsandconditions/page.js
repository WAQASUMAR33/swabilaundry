import React from "react";
import Contentsection from "./components/Contentsection";
import AboveFooter from "@/components/abovefooter";

import Termstag from "./components/termstag";

export const metadata = {
  title: "Terms and Conditions  | Swabi Laundry",
  description: "Understand the terms and conditions governing your use of Swabi Laundry’s services. Review our policies to ensure a smooth and secure experience while using our reliable and affordable laundry services.",
  keywords: "Swabi Laundry, terms and conditions, laundry services, terms of use, privacy policy, user agreements, service terms, customer policies, laundry delivery terms, service agreement, user guidelines, laundry terms, affordable laundry services",
  author: "Swabi Laundry",
  openGraph: {
    title: "Terms and Conditions | Swabi Laundry",
    description: "Understand the terms and conditions governing your use of Swabi Laundry’s services. Review our policies to ensure a smooth and secure experience while using our reliable and affordable laundry services.",
    url: "https://www.swabilaundry.com/termsandconditions",
    type: "website",
    images: [
      {
        url: "https://www.swabilaundry.com/og-image-pricing.jpg",
        width: 800,
        height: 600,
        alt: "Swabi Laundry Terms and Conditions",
      },
    ],
  },
};

export default function termsandconditions() {
  return (
    <>
      <head>
        <meta name="description" content={metadata.description} />
        <meta name="keywords" content={metadata.keywords} />
        <meta name="author" content={metadata.author} />
        <meta property="og:title" content={metadata.openGraph.title} />
        <meta property="og:description" content={metadata.openGraph.description} />
        <meta property="og:url" content={metadata.openGraph.url} />
        <meta property="og:type" content={metadata.openGraph.type} />
        <meta property="og:image" content={metadata.openGraph.images[0].url} />
        <meta property="og:image:width" content={metadata.openGraph.images[0].width} />
        <meta property="og:image:height" content={metadata.openGraph.images[0].height} />
        <meta property="og:image:alt" content={metadata.openGraph.images[0].alt} />
        <title>{metadata.title}</title>
      </head>
      <Termstag/>
      <Contentsection />
     
      <AboveFooter />
    </>
  );
}

'use client';
import React from 'react';
import { ArrowRight } from 'react-feather';

const Contentsection = () => {
  return (
    <div className="bg-gray-100 p-5 md:p-20">
      <div className="container mx-auto px-4">
   
        <p className="text-xl mb-4">
          <strong>Updated: December 5th, 2024</strong><br />
          These terms and conditions (“User Terms”) is applicable to all/visits use of our website at www.swabilaundry.ae (the “Website”), the Service and the Application (as defined below), as well as to all information, recommendations and/or services provided to you on or through the Website, the Service and the Application.
Please read these terms of service carefully. By accessing or using Swabi Laundry. Applications or any services provided by us, you agree to be bound by these terms of service. If you do not agree to all of these terms and conditions, do not access or use Swabi Laundry. Applications or any services provided by us.
 <a href="http://www.swabilaundry.ae" className="text-blue-500">www.swabilaundry.ae</a> (the “Website”), the Service, and the Application (as defined below), as well as to all information, recommendations, and/or services provided to you on or through the Website, the Service, and the Application.
          <br />
          Please read these terms of service carefully. By accessing or using Swabi Laundry’s applications or any services provided by us, you agree to be bound by these terms of service. If you do not agree to all of these terms and conditions, do not access or use Swabi Laundry’s applications or any services provided by us.
        </p>

        <h2 className="text-2xl font-semibold mt-6 mb-2">Swabi Laundry</h2>
        <p className="text-lg mb-4">
        Your contracting partner is SWABI LAUNDRY LLC. (“SL”), a corporation established in DED, Dubai, UAE.
        </p>

        <h2 className="text-2xl font-semibold mt-6 mb-2">What services does Swabi laundry provide?</h2>
        <p className="text-lg mb-4">
        Swabi laundry provides pick-up and drop off services for laundry, ironing and dry cleaning. There are several channels which can be used to request for Pick-up and delivery services. These include our Website, , web emails and other social media channels like WhatsApp, Instagram, or Facebook. All services provided by Swabi laundry to you by means of your use of the Website or Application or service requested by any other channel are hereafter referred to as the “Service”.
        </p>

        <h2 className="text-2xl font-semibold mt-6 mb-2">How is a contract concluded between Swabi laundry and you?</h2>
        <p className="text-lg mb-4">
        By using the Website, Application or the Service, you enter into a contract with Swabi laundry (the “Contract”). In order to be able to use the Application, you first need to sign up with Swabi laundry. You can also place orders via our website, emails or other social media channels like WhatsApp, Instagram, or Facebook. When signing up or placing an order via other channels, you are obligated to provide Swabi laundry with your personal information, mobile telephone number, address for pick-up and delivery, and credit card data (only requested when placing an order). Upon successful completion of your signing up with Swabi, Swabi laundry will provide you with a personal account, which may be accessible to you with a password of your choice.
For the use of our Website, Service or the Application, we require minimum age to be 18 years of age or older and therefore anyone less than 18 years of age will not be allowed to use our application/services. If you reside in a jurisdiction that restricts the use of the Service, Website, or Application because of age or restricts the ability to enter into contracts such as this one due to age, you must abide by such age limits and you must not use the Service and the Application. You represent that if you are an individual, you are of legal age to enter into a binding contract, or that if you are registering on behalf of a legal entity, that you are authorized to enter into and bind the entity to, these User Terms and register for the Service and the Application.

        </p>



        <h2 className="text-2xl font-semibold mt-6 mb-2">Your use of the Website, Application, or the Service.</h2>
        <p className="text-lg mb-4">
        You warrant that the information you provide to Swabi laundry is accurate and complete. Swabi laundry is entitled at all times to verify the information that you have provided and to refuse the Service or use of the Application without providing reasons.
        </p>

        <p className="text-lg mb-4">
        Only authorized means can be used to access the Service. You are responsible to make your own judgements to check and ensure the correct Application is downloaded for your device. Swabi laundry is not liable if you do not have a compatible mobile device or if you download the wrong version of the Application for your mobile device. Swabi laundry reserves the right to terminate the Service and the use of the Application should you be using the Service or Application with an incompatible or unauthorized device.
        </p>

        <h2 className="text-2xl font-semibold mt-6 mb-2">By using the Website, Application or the Service, you (the user) further agree that:</h2>
        <p className="text-lg mb-4">
        You will only use the Service, Website, or download the Application for your sole, personal use. You will not resell it to a third party. You will not authorize others to use your account. You are responsible for maintaining the confidentiality of your own account. You will not assign or otherwise transfer your account to any other person or legal entity. You will not use an account that is subject to any rights of a person other than you without appropriate authorization You will not use the Service, Website, or Application for unlawful purposes, including but not limited to sending or storing any unlawful material or for fraudulent purposes. You will not use the Service, Website, or Application to cause nuisance, annoyance or inconvenience. You will not impair the proper operation of the network. You will not try to harm the Service, Website, or Application in any way whatsoever. You will not copy, or distribute the Website, Application, or other Swabi laundry Content without written permission from Swabi laundry. You will keep secure and confidential your account password or any identification we provide you which allows access to the Service, Website, and the Application. You will provide us with whatever proof of identity we may reasonably request. You will not use the Service, Website, or Application with an incompatible or unauthorized device. You will comply with all applicable law from your home nation, the country, state and/or city in which you are present while using the Application, Website, or Service.
        </p>

        <p className="text-lg mb-4">
     
        Swabi laundry reserves the right to immediately terminate the Service and the use of the Website or Application should you not comply with any of the above rules.   </p>


        <h2 className="text-2xl font-semibold mt-6 mb-2">Care for Garments</h2>
        <p className="text-lg mb-4">
        Swabi laundry provides, subject to your requirements and choice, the following services: Cleaning and Pressing, Pressing Only and Wash & Fold. The cleaning could include Dry Cleaning or Cleaning with Water, and this will depend on the nature of the clothes.
        </p>

        <p className="text-lg mb-4">
        Swabi’s staff will follow each garment’s care label instructions to decide the type of cleaning which is required for the Cleaning and Pressing service. If the label is missing, we will make best effort judgement to decide the method of cleaning. If for whatsoever reason, the user requests the garment treatment to be contradictory to what has been mentioned on the care label instructions, Swabi laundry will make an attempt on a best-efforts basis and wherever possible to contact the user and advise on potential risks associated with the treatment. The user will assume responsibility for any damage to their garments if they have indicated a way of treatment to their clothes which is contrary to care label instructions.
       </p>


       <p className="text-lg mb-4">
       In the Wash & Fold service, all items are washed at forty (40) degrees celsius and dried in a medium to high heat. Swabi laundry staff will not verify that each garment is safe to undergo washing at forty (40) degrees celsius and drying at medium to high heat. The user will assume responsibility for any damage to their garment.
Swabi laundry will not guarantee the successful removal of any stain but will make every attempt to remove stains without damage to your garment.
   </p>

   <h2 className="text-2xl font-semibold mt-6 mb-2">Item Count</h2>
        <p className="text-lg mb-4">
        Swabi’s pick-up driver will only count the number of bags given by the user for cleaning and ironing. The driver will neither count or inspect the garments at collection. Any potential defects, damages or stains will not be noted down on this receipt.   </p>

        <p className="text-lg mb-4">
        The specific count of the number of items and inspection for any defects, damages or stains will be done by the store manager once the clothes reach our facility. Swabi laundry will inform the customer of any noted damages and reserves the right to decide to not clean an item and inform the customer via call, SMS, in-app chat, e-mail or with a card informing the customer that the garment was not cleaned.
          </p>



          <h2 className="text-2xl font-semibold mt-6 mb-2">Delivery</h2>
        <p className="text-lg mb-4">
        Our standard turnaround time is 48 hrs. And we will do our best to comply to these timelines unless instructed otherwise by you or under unfortunate circumstances. Swabi laundry does not charge any delivery fee but it has a minimum invoice amount of 50 AED.
        </p>



        <h2 className="text-2xl font-semibold mt-6 mb-2">Payment</h2>
        <p className="text-lg mb-4">
        While currently, the use of the Website, Application or the Service is free of charge, Swabi laundry reserves the right to introduce a fee for the use of the Application. If Swabi laundry decides to introduce such a fee, Swabi laundry shall inform you accordingly and allow you to either continue or terminate the Contract.
Swabi laundry shall charge you for the services you request, which may include dry cleaning, laundered shirts, wash & fold, pressing or related services (“Cleaning”). You agree that you will pay for all Cleaning you purchase through Swabi, and that Swabi laundry may charge your credit card account as provided by you when registering for the Service for the Cleaning (including any taxes, late fees, or additional fees as applicable) that may be accrued by or in connection with your account. Swabi laundry also provides the option to pay through cash if the User wishes to do so.
 </p>

 <p className="text-lg mb-4">
 You are responsible for the timely payment of all fees and for providing Swabi laundry with a valid credit card account for payment of all fees at all times. Any payment made is non-refundable in cash/credit card. Having said that we do provide refunds in form of store credits. Once the items have been cleaned, an email invoice will be sent detailing the number of items that were cleaned as well as the charges minus any promotions or credits accumulated.
  </p>


 <p className="text-lg mb-4">
 Please note once you place a pick-up request on the app with Payment method as Credit card, Swabi laundry will authorize the credit card by blocking a small amount of 1$. This will be immediately refunded if you were to cancel the pick-up request anytime before the actual pick-up were to be made. </p>


 <p className="text-lg mb-4">
 Payments will be processed immediately after the items have been cleaned by our laundry, and prior to delivery; any rejected credit card transactions will need to be settled before the delivery of the cleaned items.
Once your payment has been processed the customer will be notified through email and confirmation message displayed on the screen. In case Swabi laundry were to authorize a token amount from your card once you are placing an pick-up request, the customer will be notified through SMS.
 </p>

 <p className="text-lg mb-4">
 All payment confirmation and communication will be received by the customer within a maximum of 24hrs since the deduction happened. Swabi laundry uses a third-party payment processor, https://.telr.com (the “Payment Processor”) to link your credit card account to the Application and Service. The processing of payments or credits, as applicable, in connection with your use of the Website, Application and Service will be subject to the terms, conditions and privacy policies of the Payment Processor and your credit card issuer in addition to these User Terms. Swabi laundry is not responsible for any errors by the Payment Processor, but will take corrective action when and if possible. In connection with your use of the Services, Swabi laundry will obtain certain transaction details, which Swabi laundry will use solely in accordance with its Privacy Policy.
  </p>

  <p className="text-lg mb-4">
  Please note, we accept Visa and MasterCard and accept payments in AED
  </p>

  <p className="text-lg mb-4">
  Also every cardholder must retain a copy of transaction records and Swabi laundry policies and rules.
   </p>



   <h2 className="text-2xl font-semibold mt-6 mb-2">Indemnification</h2>
        <p className="text-lg mb-4">
   
        The User, by accepting these User Terms and using the Application or Service, undertakes to Swabi laundry that if Swabi, its affiliates, its licensors, and each of their officers, directors, other users, employees, attorneys, agents and suppliers that by accepting these User Terms and using the Application or Service incurs any claims, costs, damages, losses, liabilities and expenses (including attorneys’ fees and costs) arising out of or in connection with: (a) your violation or breach of any term of these User Terms or any applicable law or regulation, whether or not referenced herein; (b) your violation of any rights of any third party, or (c) your use or misuse of the Application or Service, the User must pay to Swabi laundry on demand, on an after tax basisa, an amount equal to such loss.
The User will indemnify and hold Swabi, harmless from and against any such claims which might have come as a result herewith
       </p>



       <h2 className="text-2xl font-semibold mt-6 mb-2">Liability</h2>
        <p className="text-lg mb-4">
   
        The information, recommendations and/or services provided to you on or through the Website, the Service, and the Application is for general information purposes only and does not constitute advice. While Swabi laundry will endeavor to reasonably keep the Website and the Application and its contents correct and up to date but does not guarantee that (the contents of) the Website and/or Application are free of errors, defects, malware, and viruses or that the Website and/or Application are correct, up to date and accurate.      
         </p>

         <p className="text-lg mb-4">
   
   The information, recommendations and/or services provided to you on or through the Website, the Service, and the Application is for general information purposes only and does not constitute advice. While Swabi laundry will endeavor to reasonably keep the Website and the Application and its contents correct and up to date but does not guarantee that (the contents of) the Website and/or Application are free of errors, defects, malware, and viruses or that the Website and/or Application are correct, up to date and accurate.      
    </p>


    <p className="text-lg mb-4">
   
    Swabi laundry shall not be liable for any damages resulting from the use of (or inability to use) the Website or Application (but to the exclusion of death or personal injury), including damages caused by malware, viruses or any incorrectness or incompleteness of the Information or the Website or Application, unless such damage is the result of any wilful misconduct or from gross negligence on the part of Swabi laundry.
    </p>


    <p className="text-lg mb-4">
   
    Swabi laundry shall further not be liable for damages resulting from the use of (or the inability to use) electronic means of communication with the Website or the Application, including and but not limited to damages resulting from failure or delay in delivery of electronic communications, interception or manipulation of electronic communications by third parties or by computer programs used for electronic communications and transmission of viruses or damages to any User’s electronic device as a result of the usage of the application or the Website
User understands that there are inherent risks in Cleaning and there is potential for clothing and related items to get lost or damaged. Swabi laundry will do its best to ensure situations like this do not happen, and in the instances, they do happen, will work with the User to rectify the situation.

    </p>

    <p className="text-lg mb-4">
   
    Without prejudice to the foregoing, and insofar as allowed under mandatory applicable law and according to the industry practices, Swabi’s aggregate liability shall in no event exceed an amount of five times the cost quoted for washing/ cleaning that specific item and in no event will exceed AED 500 or, where applicable, the equivalent of that amount in the currency used by you for the payment for Cleaning.
   </p>




   <h2 className="text-2xl font-semibold mt-6 mb-2">Damaged Items</h2>
        <p className="text-lg mb-4">
   
        Swabi laundry will take all efforts to ensure that proper care is taken care while cleaning all garments. However, in unforeseen circumstances where garments are damaged, it is the responsibility of the User to report any damaged item within seven (7) days of the date of delivery of the garments to info@swabilaundry.com or through in-app chat. Swabi laundry reserves the right to reject any claim made more than seven (7) days after the successful delivery of the garments to the customer.    </p>

         <p className="text-lg mb-4">
   
         Taking care of your garments is our number one priority. We strive to provide exceptional service. While we are very cautious to treat all garments carefully, we cannot guarantee against colour bleeding, colour loss, or shrinkage of garments associated with a manufacturing defect. In addition, we do not take responsibility for any deteriorated or flawed garments, which could result in small holes or tears associated with the conditions a garment is exposed to during wear. Damages to garments may occur due to our cleaning and ironing processes, as well as due to defects in the fabric, material, stitching of the garments. We will, to the best of our ability, assess the damages impartially and determine the root cause of the damage.
    </p>


    <p className="text-lg mb-4">
   
    For any items deemed damaged because of our process, Swabi laundry may reimburse you by paying up to five (5) times the charge for cleaning the item regardless of brand, price or condition of the garment. The reimbursement will be in credit notes which can be used for future services from us. Any damaged items must be reported info@swabilaundry.com and inspected by Swabi laundry within seven (7) days through digital photos and in-person.
    </p>


    <p className="text-lg mb-4">
   
    For any items deemed damaged because of a perceived defect, Swabi laundry may reimburse you by paying up to five (5) times the charge for cleaning the item regardless of brand, price or condition of the garment.
Without prejudice to the foregoing, and insofar as allowed under mandatory applicable law and according to the industry practices, Swabi’s aggregate liability shall in no event exceed an amount of AED 500 or, where applicable, the equivalent of that amount in the currency used by you for the payment for Cleaning.

    </p>

    <p className="text-lg mb-4">
   
    We also understand that sometimes Users might not be able to assess the damage within 7 days given travel plans or work schedules. Claims made more than seven (7) days after delivery will be assessed on a case-by-case basis and we will do our best to see what can be done
In case any damaged item claim cannot be resolved amicably according to terms and conditions, Swabi laundry will refer the customer to file a claim with the applicable consumer rights authority. The resolution of the claim will be as per the terms of the impartial decision made by the independent authority.

   </p>

   <h2 className="text-2xl font-semibold mt-6 mb-2">Lost Items</h2>
        <p className="text-lg mb-4">
   
        Any lost item must be reported within seven (7) days of the date of delivery of the garments to info@swabilaundry.com or through in-app chat. All claims are reviewed on a case-by-case basis. Items are considered lost five (5) days after the initial claim has been made. In line with industry practices, any reimbursement for an item deemed lost by Swabi laundry shall be limited to five (5) times the charge for treating the garment.
       </p>
      
         <p className="text-lg mb-4">
   
         Swabi laundry shall not take responsibility for any loose items lost when submitted in a Swabi laundry bag, such as watches, jewelry, cash, wallets, cufflinks, car keys, badges or any other such items regardless of their value.
Without prejudice to the foregoing, and insofar as allowed under mandatory applicable law and according to the industry practices, Swabi’s aggregate liability shall in no event exceed an amount of AED 500 or, where applicable, the equivalent of that amount in the currency used by you for the payment for Cleaning.

    </p>


    <p className="text-lg mb-4">
   
    In case any damaged item claim cannot be resolved amicably according to terms and conditions, Swabi laundry will refer the customer to file a claim with the applicable consumer rights authority. The resolution of the claim will be as per the terms of the impartial decision made by the independent authority.
    </p>

    <h2 className="text-2xl font-semibold mt-6 mb-2">Unclaimed Items</h2>
        <p className="text-lg mb-4">
   
        Orders not claimed after 30 days from original delivery date will be removed from our facility with or without customer's consent.
       </p>
      
         <p className="text-lg mb-4">
   
         Our team will attempt to contact the customer for a maximum of 2 times within the initial 30 days of non-delivery. Should no contact is established nor any confirmation on delivery from the customer, the items would then be included in the unclaimed items and will be removed from the facility.
    </p>


    <h2 className="text-2xl font-semibold mt-6 mb-2">Cancellation/Refund policy</h2>
        <p className="text-lg mb-4">
   
        As mentioned earlier while Swabi laundry does not provide refunds in Cash and credit cards, it will provide store credits will be provided in case there is an issue with one (or many) items
Not upto your expectation and our quality standards (i.e. not serviced properly) Wear and tear of the item (Refer to the detailed policy of the damaged item in the section above) Missing item (Refer to the detailed policy of the Lost item in the section above)
Please not once you place a pick-up request on the app with Payment method as Credit card, Swabi laundry will authorize the credit card by blocking a small amount of 1$. This will be immediately refunded if you were to cancel the pick-up request anytime before the actual collection of the item were to be made.
Once your order has been handed over to Swabi, a client cannot cancel his request of service. In case he does, the user will not be paid any amount in cash. Its upto the discretion of Swabi laundry to decide on the store credit amount that is to be given to the customer. The store credit would be invoice amount after deducting the logistics and processing cost of this request.

       </p>
      
         <p className="text-lg mb-4">
   
         Please note in case we havent started the cleaning process of your order, we will refund the entire amount in form of store credits after deducting 45 AED
    </p>
   

    <h2 className="text-2xl font-semibold mt-6 mb-2">Privacy Policy</h2>
        <p className="text-lg mb-4">
   
        Swabi laundry may collect and process the personal data of the visitors of the Website and users of the Application according to the Privacy Policy. Please refer to our application and website to go through the Privacy Policy
Swabi laundry may collect the brands of all garments submitted by its customers.

       </p>

      



    <h2 className="text-2xl font-semibold mt-6 mb-2">Applicable law and Venue</h2>
        <p className="text-lg mb-4">
   
        The Terms and your use of the Service, including, but not limited to, the Application will be governed by and construed in accordance with the laws of the Dubai, Abu Dhabi and the UAE. Any dispute in relation to these terms and conditions shall be settled by the competent Courts of Dubai.
       </p>

       <p className="text-lg mb-4">
   
       Moreover, in compliance with local laws, we will not trade with or provide any services to OFAC and sanctioned countries.
  </p>


    <h2 className="text-2xl font-semibold mt-6 mb-2">Miscellaneous</h2>
        <p className="text-lg mb-4">
   
        If any part of these Terms is determined to be invalid or unenforceable pursuant to applicable law, including, without limitation, the warranty disclaimers and liability limitations set forth above, then the invalid or unenforceable provision will be deemed superseded by a valid, enforceable provision that most closely matches the intent of the original provision and the remainder of these Terms will continue in full effect. Only you and Swabi laundry are entitled to enforce these Terms. No third party will be entitled to enforce any of the terms and conditions herein.
       </p>
      
       

    <h2 className="text-2xl font-semibold mt-6 mb-2">Final provision</h2>
        <p className="text-lg mb-4">
   
        The English text of these User Terms constitutes the sole authentic text. In the event of any discrepancy between the English text and a translation into a foreign language, the English text shall prevail.
       </p>
      
         <p className="text-lg mb-4">
   
         The Website Policies and Terms & Conditions may be changed or updated occasionally to meet the requirements and standards. Therefore, the Customers are encouraged to frequently visit these sections to be updated about the changes on the website. Modifications will be effective on the day they are posted
    </p>


    <h2 className="text-2xl font-semibold mt-6 mb-2">Our Corporate Addresses</h2>
        <p className="text-lg mb-4">
        Swabi laundry <br/> Shop #1, K-04, Greece Cluster <br/> International City, Dubai,<br/>  United Arab Emirates
       </p>


       <h2 className="text-2xl font-semibold mt-6 mb-2">PHONE NUMBER</h2>
        <p className="text-lg mb-4">
        +971 58 992 0080
       </p>


      </div>
    </div>
  );
};

export default Contentsection;
